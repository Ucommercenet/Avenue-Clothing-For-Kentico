SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CI_Migration](
	[MigrationID] [int] IDENTITY(1,1) NOT NULL,
	[MigrationName] [nvarchar](255) NOT NULL,
	[DateApplied] [datetime2](3) NOT NULL,
	[RowsAffected] [int] NULL,
 CONSTRAINT [PK_CI_Migration] PRIMARY KEY CLUSTERED 
(
	[MigrationID] ASC
)
)

GO
SET ANSI_PADDING ON

GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_CI_Migration_MigrationName] ON [dbo].[CI_Migration]
(
	[MigrationName] ASC
)
GO
ALTER TABLE [dbo].[CI_Migration] ADD  CONSTRAINT [DEFAULT_CI_Migration_DateApplied]  DEFAULT (sysdatetime()) FOR [DateApplied]
GO
ALTER TABLE [dbo].[CI_Migration] ADD  CONSTRAINT [DEFAULT_CI_Migration_RowsAffected]  DEFAULT (NULL) FOR [RowsAffected]
GO
