SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[COM_Brand](
	[BrandID] [int] IDENTITY(1,1) NOT NULL,
	[BrandDisplayName] [nvarchar](200) NOT NULL,
	[BrandName] [nvarchar](200) NOT NULL,
	[BrandDescription] [nvarchar](max) NULL,
	[BrandHomepage] [nvarchar](400) NULL,
	[BrandThumbnailGUID] [uniqueidentifier] NULL,
	[BrandSiteID] [int] NOT NULL,
	[BrandEnabled] [bit] NOT NULL,
	[BrandGuid] [uniqueidentifier] NOT NULL,
	[BrandLastModified] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_COM_Brand] PRIMARY KEY CLUSTERED 
(
	[BrandID] ASC
)
)

GO
SET ANSI_PADDING ON

GO
CREATE NONCLUSTERED INDEX [IX_COM_Brand_BrandDisplayName] ON [dbo].[COM_Brand]
(
	[BrandDisplayName] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_Brand_BrandSiteID_BrandEnabled] ON [dbo].[COM_Brand]
(
	[BrandSiteID] ASC,
	[BrandEnabled] ASC
)
GO
ALTER TABLE [dbo].[COM_Brand] ADD  CONSTRAINT [DEFAULT_COM_Brand_BrandDisplayName]  DEFAULT (N'') FOR [BrandDisplayName]
GO
ALTER TABLE [dbo].[COM_Brand] ADD  CONSTRAINT [DEFAULT_COM_Brand_BrandName]  DEFAULT (N'') FOR [BrandName]
GO
ALTER TABLE [dbo].[COM_Brand] ADD  CONSTRAINT [DEFAULT_COM_Brand_BrandSiteID]  DEFAULT ((0)) FOR [BrandSiteID]
GO
ALTER TABLE [dbo].[COM_Brand] ADD  CONSTRAINT [DEFAULT_COM_Brand_BrandEnabled]  DEFAULT ((1)) FOR [BrandEnabled]
GO
ALTER TABLE [dbo].[COM_Brand] ADD  CONSTRAINT [DEFAULT_COM_Brand_BrandGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [BrandGuid]
GO
ALTER TABLE [dbo].[COM_Brand] ADD  CONSTRAINT [DEFAULT_COM_Brand_BrandLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [BrandLastModified]
GO
ALTER TABLE [dbo].[COM_Brand]  WITH CHECK ADD  CONSTRAINT [FK_COM_Brand_BrandSiteID_CMS_Site] FOREIGN KEY([BrandSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[COM_Brand] CHECK CONSTRAINT [FK_COM_Brand_BrandSiteID_CMS_Site]
GO
